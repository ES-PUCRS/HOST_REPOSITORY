public class Main {
    public static void main(String[] args) {
        JantarUm jantarUm = new JantarUm(2);
        JantarDois jantarDois = new JantarDois(2);
        jantarUm.run();
        jantarDois.run();
    }
}