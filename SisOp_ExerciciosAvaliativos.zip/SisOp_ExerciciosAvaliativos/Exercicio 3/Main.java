public class Main {
    public static void main(String[] args) {
        Barreiras barreira = new Barreiras();
        barreira.run();
    }
}