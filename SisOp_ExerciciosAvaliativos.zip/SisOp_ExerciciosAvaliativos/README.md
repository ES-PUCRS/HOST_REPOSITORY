# SisOp_ExerciciosAvaliativos

## Como executar os projetos
cd pasta_projeto
./run.bat [numero do exercicio]